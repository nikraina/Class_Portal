# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Project::Application.config.secret_key_base = '68be7d69df7e71f07cb0172f1fc5cda9c5a9bf0f76223d15a4d82b553d0d51d7dfe9433d83e04427dca2db3619e7d5227916de40d7effeb3d2a9ad016d6de804'
