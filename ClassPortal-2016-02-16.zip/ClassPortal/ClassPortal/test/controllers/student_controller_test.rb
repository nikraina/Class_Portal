require 'test_helper'

class StudentControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
