require 'test_helper'

class StudentHelperTest < ActionView::TestCase
end
