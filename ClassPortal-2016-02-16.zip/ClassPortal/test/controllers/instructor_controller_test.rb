require 'test_helper'

class InstructorControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
