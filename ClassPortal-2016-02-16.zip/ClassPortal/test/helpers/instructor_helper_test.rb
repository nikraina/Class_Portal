require 'test_helper'

class InstructorHelperTest < ActionView::TestCase
end
